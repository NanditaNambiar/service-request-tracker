package Service_request_tracker.example.srt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrtApplicationTests {

	@Test
	void contextLoads() {
	}

}
