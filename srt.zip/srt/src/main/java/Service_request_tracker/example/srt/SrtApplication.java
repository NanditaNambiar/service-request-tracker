package Service_request_tracker.example.srt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrtApplication.class, args);
	}

}
